-- Inserting sample records into Customers
INSERT INTO Customers (customer_id, name, DOB, email, contact_info, address) VALUES
(1, 'Kassem', '1985-04-12', 'kassem@email.com', '555-1234', '123 Street'),
(2, 'Waseem', '1990-08-25', 'waseem@email.com', '555-5678', '456 Oak Avenue'),
(3, 'Muaz', '1995-02-06', 'muaz@email.com', '555-6589', '789 Pine Road'),
(4, 'Afra', '1970-01-03', 'Afra@email.com', '555-4853', '658 Cashew Road'),
(5, 'Jude', '1975-02-03', 'Jude@email.com', '555-9854', '452 Almond Road');

-- Inserting sample records into Hats
INSERT INTO Hats (hat_id, brand_id, price, brand_name, style, size, quantity) VALUES
(1, 101, 19.99, 'Nike', 'fedora', 7, 10),
(2, 102, 29.99, 'Adidas', 'beanie', 6, 15),
(3, 103, 24.99, 'PUMA', 'baseball', 7, 20);

-- Inserting sample records into Orders
INSERT INTO Orders (order_id, customer_id, hat_id, date, quantity) VALUES
(1, 1, 1, '2023-01-15', 2),
(2, 2, 2, '2023-02-20', 1),
(3, 3, 3, '2023-03-10', 3);

-- Inserting sample records into Delivery
INSERT INTO Delivery (delivery_id, order_id, arrival_date) VALUES
(1, 1, '2023-01-20'),
(2, 2, '2023-02-25');

-- Inserting sample records into Bills
INSERT INTO Bills (bill_id, order_id, tax, price, payment_method) VALUES
(1, 1, 1.50, 39.98, 'credit card'),
(2, 2, 2.25, 29.99, 'credit card'),
(3, 3, 1.80, 74.97, 'debit card');

-- Inserting sample records into Order_Details for many-to-many relationship including quantity
INSERT INTO Order_Details (order_id, hat_id, quantity) VALUES
(1, 1, 2), -- Assuming order 1 includes 2 of hat 1
(2, 2, 1), -- Assuming order 2 includes 1 of hat 2
(3, 3, 3), -- Assuming order 3 includes 3 of hat 3
(3, 1, 1); -- Assuming order 3 includes 1 of hat 1, this order includes multiple types of hats