-- Creating the table for Customers
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY NOT NULL,
    name VARCHAR(255) NOT NULL,
    DOB DATE NOT NULL,
    email VARCHAR(255) NOT NULL,
    contact_info VARCHAR(255),
    address VARCHAR(255) NOT NULL
);

-- Creating the table for Hats first, because it is referenced by other tables
CREATE TABLE Hats (
    hat_id INT PRIMARY KEY NOT NULL,
    brand_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    brand_name VARCHAR(255) NOT NULL,
    style VARCHAR(255) NOT NULL,
    size INT NOT NULL,
    quantity INT NOT NULL
);

-- Creating the table for Orders after Hats table has been created
CREATE TABLE Orders (
    order_id INT PRIMARY KEY NOT NULL,
    customer_id INT NOT NULL,
    hat_id INT NOT NULL,
    date DATE NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (hat_id) REFERENCES Hats(hat_id)
);

-- Creating the table for Delivery
CREATE TABLE Delivery (
    delivery_id INT PRIMARY KEY NOT NULL,
    order_id INT NOT NULL,
    arrival_date DATE,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);

-- Creating the table for Bills
CREATE TABLE Bills (
    bill_id INT PRIMARY KEY NOT NULL,
    order_id INT NOT NULL,
    tax DECIMAL(10,2) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(255) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);

-- Creating an associative table for the many-to-many relationship between Orders and Hats
CREATE TABLE Order_Details (
    order_id INT NOT NULL,
    hat_id INT NOT NULL,
    quantity INT NOT NULL,
    PRIMARY KEY (order_id, hat_id),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (hat_id) REFERENCES Hats(hat_id)
);
